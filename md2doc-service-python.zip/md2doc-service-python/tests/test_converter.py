"""
测试用例
验证 md2doc-mcp 的各项功能
"""

import pytest
import tempfile
import os
from src.md2doc_mcp.core.converter import MarkdownToWordConverter
from src.md2doc_mcp.parser.markdown_parser import MarkdownParser
from src.md2doc_mcp.parser.table_parser import MarkdownTableParser
from src.md2doc_mcp.core.echarts_converter import EChartsToWordConverter
from src.md2doc_mcp.models.word_params import WordParams


class TestMarkdownParser:
    """测试 Markdown 解析器"""
    
    def test_extract_headers(self):
        """测试标题提取"""
        markdown = """# 标题1
## 标题2
### 标题3
普通段落"""
        
        headers = MarkdownParser.extract_headers(markdown)
        assert len(headers) == 3
        assert headers[0] == (1, "标题1")
        assert headers[1] == (2, "标题2")
        assert headers[2] == (3, "标题3")
    
    def test_extract_echarts_blocks(self):
        """测试 ECharts 代码块提取"""
        markdown = """# 图表测试
```echarts
{
  title: { text: '测试图表' },
  xAxis: { data: ['A', 'B', 'C'] },
  series: [{ data: [1, 2, 3] }]
}
```
普通文本"""
        
        echarts_blocks = MarkdownParser.extract_echarts_blocks(markdown)
        assert len(echarts_blocks) == 1
        assert "title: { text: '测试图表' }" in echarts_blocks[0]
    
    def test_extract_tables(self):
        """测试表格提取"""
        markdown = """# 表格测试
| 列1 | 列2 | 列3 |
|-----|-----|-----|
| 值1 | 值2 | 值3 |
| 值4 | 值5 | 值6 |
普通文本"""
        
        tables = MarkdownParser.extract_tables(markdown)
        assert len(tables) == 1
        assert "列1" in tables[0]


class TestTableParser:
    """测试表格解析器"""
    
    def test_parse_table(self):
        """测试表格解析"""
        table_markdown = """| 列1 | 列2 | 列3 |
|-----|-----|-----|
| 值1 | 值2 | 值3 |
| 值4 | 值5 | 值6 |"""
        
        table_data = MarkdownTableParser.parse_table(table_markdown)
        assert len(table_data) == 3  # 包括表头
        assert table_data[0] == ["列1", "列2", "列3"]
        assert table_data[1] == ["值1", "值2", "值3"]
        assert table_data[2] == ["值4", "值5", "值6"]


class TestEChartsConverter:
    """测试 ECharts 转换器"""
    
    def test_convert_echarts_to_json(self):
        """测试 ECharts 配置转换为 JSON"""
        echarts_config = """{
  title: { text: '测试图表' },
  xAxis: { data: ['A', 'B', 'C'] },
  series: [{ data: [1, 2, 3] }]
}"""
        
        json_config = EChartsToWordConverter.convert_echarts_to_json(echarts_config)
        
        # 验证转换后的 JSON 是有效的
        import json
        parsed = json.loads(json_config)
        assert parsed["title"]["text"] == "测试图表"
        assert parsed["xAxis"]["data"] == ["A", "B", "C"]
        assert parsed["series"][0]["data"] == [1, 2, 3]
    
    def test_convert_echarts_to_word_chart(self):
        """测试 ECharts 转换为 Word 图表"""
        params = WordParams.create()
        echarts_config = """{
  title: { text: '测试图表' },
  xAxis: { data: ['A', 'B', 'C'] },
  series: [{ name: '系列1', data: [1, 2, 3] }]
}"""
        
        EChartsToWordConverter.convert_echarts_to_word_chart(params, "chart1", echarts_config)
        
        chart = params.get_chart("chart1")
        assert chart is not None
        assert chart.title == "测试图表"
        assert list(chart.get_x_axis()) == ["A", "B", "C"]
        
        y_axis = chart.get_y_axis("系列1")
        assert y_axis is not None
        assert list(y_axis) == [1, 2, 3]


class TestWordParams:
    """测试 Word 参数管理器"""
    
    def test_text_param(self):
        """测试文本参数"""
        params = WordParams.create()
        params.setText("title", "测试标题")
        
        param = params.get_param("title")
        assert param is not None
        assert param.msg == "测试标题"
    
    def test_table_param(self):
        """测试表格参数"""
        params = WordParams.create()
        table_data = [["列1", "列2"], ["值1", "值2"]]
        params.set_param("table1", WordParams.table(table_data))
        
        param = params.get_param("table1")
        assert param is not None
        assert param.data == table_data
    
    def test_chart_param(self):
        """测试图表参数"""
        params = WordParams.create()
        chart = params.add_chart("chart1")
        chart.set_title("测试图表")
        
        retrieved_chart = params.get_chart("chart1")
        assert retrieved_chart is not None
        assert retrieved_chart.title == "测试图表"


class TestMarkdownToWordConverter:
    """测试主转换器"""
    
    def test_validate_markdown_content(self):
        """测试 Markdown 内容验证"""
        converter = MarkdownToWordConverter()
        
        # 有效内容
        assert converter.validate_markdown_content("# 标题\n\n内容")
        
        # 无效内容
        assert not converter.validate_markdown_content("")
        assert not converter.validate_markdown_content("   ")
    
    def test_get_supported_features(self):
        """测试获取支持的功能"""
        converter = MarkdownToWordConverter()
        features = converter.get_supported_features()
        
        assert len(features) > 0
        assert "Markdown 标题 (H1-H6)" in features
        assert "Markdown 表格" in features
        assert "ECharts 图表代码块" in features
    
    def test_convert_simple_markdown(self):
        """测试简单 Markdown 转换"""
        converter = MarkdownToWordConverter()
        
        markdown_content = """# 测试文档

这是一个测试文档。

## 子标题

这是子标题下的内容。"""
        
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as tmp_file:
            output_path = tmp_file.name
        
        try:
            converter.convert_markdown_to_word(markdown_content, output_path)
            
            # 验证文件是否生成
            assert os.path.exists(output_path)
            assert os.path.getsize(output_path) > 0
            
        finally:
            # 清理临时文件
            if os.path.exists(output_path):
                os.remove(output_path)
    
    def test_convert_markdown_with_table(self):
        """测试包含表格的 Markdown 转换"""
        converter = MarkdownToWordConverter()
        
        markdown_content = """# 表格测试

| 列1 | 列2 | 列3 |
|-----|-----|-----|
| 值1 | 值2 | 值3 |
| 值4 | 值5 | 值6 |"""
        
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as tmp_file:
            output_path = tmp_file.name
        
        try:
            converter.convert_markdown_to_word(markdown_content, output_path)
            
            # 验证文件是否生成
            assert os.path.exists(output_path)
            assert os.path.getsize(output_path) > 0
            
        finally:
            # 清理临时文件
            if os.path.exists(output_path):
                os.remove(output_path)
    
    def test_convert_markdown_with_echarts(self):
        """测试包含 ECharts 的 Markdown 转换"""
        converter = MarkdownToWordConverter()
        
        markdown_content = """# 图表测试

```echarts
{
  title: { text: '测试图表' },
  xAxis: { data: ['A', 'B', 'C'] },
  series: [{ name: '系列1', data: [1, 2, 3] }]
}
```"""
        
        with tempfile.NamedTemporaryFile(suffix='.docx', delete=False) as tmp_file:
            output_path = tmp_file.name
        
        try:
            converter.convert_markdown_to_word(markdown_content, output_path)
            
            # 验证文件是否生成
            assert os.path.exists(output_path)
            assert os.path.getsize(output_path) > 0
            
        finally:
            # 清理临时文件
            if os.path.exists(output_path):
                os.remove(output_path)


if __name__ == "__main__":
    pytest.main([__file__])
