"""
Word 文档生成器
对应 Java 版本的 PoiWordGenerator.java
"""

import re
from typing import List, Dict, Any
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.shared import OxmlElement, qn
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from md2doc_mcp.models.word_params import WordParams, TextParam, TableParam, ImageParam
from md2doc_mcp.models.chart_table import ChartTable


class PoiWordGenerator:
    """Word 文档生成器
    
    读取模板文档，替换文本占位符，插入表格（带表头背景色），插入图表
    保存最终文档
    """
    
    @staticmethod
    def build_doc(params: WordParams, template_file: str, output_file: str) -> bool:
        """构建 Word 文档
        
        Args:
            params: Word 参数对象
            template_file: 模板文件路径
            output_file: 输出文件路径
            
        Returns:
            是否成功构建文档
        """
        try:
            # 打开模板文档
            document = Document(template_file)
            
            # 替换段落中的占位符
            PoiWordGenerator._replace_paragraphs(document, params)
            
            # 替换图表占位符
            PoiWordGenerator._replace_charts(document, params)
            
            # 保存文档
            document.save(output_file)
            return True
            
        except Exception as e:
            print(f"构建文档时出错: {e}")
            return False
    
    @staticmethod
    def _replace_paragraphs(document: Document, params: WordParams) -> None:
        """替换段落中的占位符
        
        Args:
            document: Word 文档对象
            params: Word 参数对象
        """
        for paragraph in document.paragraphs:
            PoiWordGenerator._replace_paragraph_content(paragraph, params)
    
    @staticmethod
    def _replace_paragraph_content(paragraph, params: WordParams) -> None:
        """替换段落内容中的占位符
        
        Args:
            paragraph: 段落对象
            params: Word 参数对象
        """
        # 获取段落的所有文本
        full_text = paragraph.text
        
        # 查找所有占位符
        placeholder_pattern = r'\$\{([^}]+)\}'
        matches = list(re.finditer(placeholder_pattern, full_text))
        
        if not matches:
            return
        
        # 从后往前替换，避免位置偏移
        for match in reversed(matches):
            placeholder = match.group(0)  # ${key}
            key = match.group(1)  # key
            
            # 获取参数值
            param = params.get_param(key)
            
            if param is None:
                continue
            
            if isinstance(param, TextParam):
                # 替换文本
                PoiWordGenerator._replace_text_in_paragraph(paragraph, placeholder, param.msg)
            elif isinstance(param, TableParam):
                # 替换为表格
                PoiWordGenerator._replace_with_table(paragraph, placeholder, param.data)
            elif isinstance(param, ImageParam):
                # 替换为图像
                PoiWordGenerator._replace_with_image(paragraph, placeholder, param)
    
    @staticmethod
    def _replace_text_in_paragraph(paragraph, placeholder: str, replacement: str) -> None:
        """在段落中替换文本
        
        Args:
            paragraph: 段落对象
            placeholder: 占位符文本
            replacement: 替换文本
        """
        # 清空段落内容
        paragraph.clear()
        
        # 添加新文本
        run = paragraph.add_run(replacement)
        run.font.name = '宋体'
        run.font.size = Pt(12)
    
    @staticmethod
    def _replace_with_table(paragraph, placeholder: str, table_data: List[List[str]]) -> None:
        """用表格替换占位符
        
        Args:
            paragraph: 段落对象
            placeholder: 占位符文本
            table_data: 表格数据
        """
        # 清空段落内容
        paragraph.clear()
        
        # 在段落后插入表格
        document = paragraph._element.getparent().getparent()  # 获取文档对象
        table = document.add_table(rows=len(table_data), cols=len(table_data[0]) if table_data else 0)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        
        # 设置表格样式
        table.style = 'Table Grid'
        
        # 填充表格数据
        for i, row_data in enumerate(table_data):
            row = table.rows[i]
            
            # 确保有足够的单元格
            while len(row.cells) < len(row_data):
                row.add_cell()
            
            for j, cell_data in enumerate(row_data):
                cell = row.cells[j]
                cell.text = cell_data
                
                # 设置单元格居中对齐
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                # 设置表头背景色
                if i == 0:  # 第一行
                    PoiWordGenerator._set_cell_background(cell, "B4C6E7")
    
    @staticmethod
    def _replace_with_image(paragraph, placeholder: str, image_param: ImageParam) -> None:
        """用图像替换占位符
        
        Args:
            paragraph: 段落对象
            placeholder: 占位符文本
            image_param: 图像参数
        """
        # 清空段落内容
        paragraph.clear()
        
        # 添加图像
        try:
            from io import BytesIO
            image_stream = BytesIO(image_param.image_data)
            paragraph.add_run().add_picture(image_stream, width=Inches(image_param.width / 914400))
        except Exception as e:
            print(f"添加图像时出错: {e}")
            paragraph.add_run("图像加载失败")
    
    @staticmethod
    def _set_cell_background(cell, color: str) -> None:
        """设置单元格背景色
        
        Args:
            cell: 单元格对象
            color: 颜色值（如 "B4C6E7"）
        """
        try:
            # 获取单元格的 XML 元素
            cell_xml = cell._tc
            
            # 创建背景色元素
            shading = OxmlElement('w:shd')
            shading.set(qn('w:val'), 'clear')
            shading.set(qn('w:color'), 'auto')
            shading.set(qn('w:fill'), color)
            
            # 获取或创建段落属性
            p_pr = cell.paragraphs[0]._element.get_or_add_pPr()
            p_pr.append(shading)
            
        except Exception as e:
            print(f"设置单元格背景色时出错: {e}")
    
    @staticmethod
    def _replace_charts(document: Document, params: WordParams) -> None:
        """替换图表占位符
        
        Args:
            document: Word 文档对象
            params: Word 参数对象
        """
        # 查找所有图表占位符
        for paragraph in document.paragraphs:
            text = paragraph.text
            chart_pattern = r'\$\{chart(\d+)\}'
            matches = re.finditer(chart_pattern, text)
            
            for match in matches:
                chart_key = f"chart{match.group(1)}"
                chart_table = params.get_chart(chart_key)
                
                if chart_table:
                    # 清空段落内容
                    paragraph.clear()
                    
                    # 创建图表
                    try:
                        PoiWordGenerator._create_chart_in_paragraph(paragraph, chart_table)
                    except Exception as e:
                        print(f"创建图表时出错: {e}")
                        paragraph.add_run(f"图表 {chart_key} 创建失败")
    
    @staticmethod
    def _create_chart_in_paragraph(paragraph, chart_table: ChartTable) -> None:
        """在段落中创建图表
        
        Args:
            paragraph: 段落对象
            chart_table: 图表数据表
        """
        # 由于 python-docx 的图表功能有限，我们创建一个简单的表格来表示图表
        # 在实际应用中，可能需要使用 python-pptx 或其他库来创建真正的图表
        
        # 创建图表标题
        title_run = paragraph.add_run(f"{chart_table.title}\n")
        title_run.bold = True
        title_run.font.name = '宋体'
        title_run.font.size = Pt(14)
        
        # 创建数据表格
        document = paragraph._element.getparent().getparent()
        
        # 准备表格数据
        x_data = list(chart_table.get_x_axis())
        y_axes = chart_table.get_y_axis_dict()
        
        if not x_data or not y_axes:
            paragraph.add_run("图表数据为空")
            return
        
        # 创建表格
        max_rows = len(x_data)
        max_cols = 1 + len(y_axes)  # X轴 + Y轴数量
        
        table = document.add_table(rows=max_rows + 1, cols=max_cols)  # +1 for header
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = 'Table Grid'
        
        # 设置表头
        header_row = table.rows[0]
        header_row.cells[0].text = "类别"
        header_row.cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        col_index = 1
        for series_name in y_axes.keys():
            if col_index < len(header_row.cells):
                header_row.cells[col_index].text = series_name
                header_row.cells[col_index].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                PoiWordGenerator._set_cell_background(header_row.cells[col_index], "B4C6E7")
            col_index += 1
        
        # 填充数据
        for i, x_value in enumerate(x_data):
            if i + 1 < len(table.rows):
                row = table.rows[i + 1]
                row.cells[0].text = str(x_value)
                row.cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                
                col_index = 1
                for series_name, y_axis in y_axes.items():
                    if col_index < len(row.cells) and i < len(y_axis.data_list):
                        row.cells[col_index].text = str(y_axis.data_list[i])
                        row.cells[col_index].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                    col_index += 1
